from SUBMENUS import menu_company,menu_customer,menu_product,menu_sale

def menu_principal():
    while True:
        print("\nMenú Facturación:")
        print("1. Empresa")
        print("2. Cliente")
        print("3. Producto")
        print("4. Ventas")
        print("5. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            menu_company()
        elif opcion == '2':
            menu_customer()
        elif opcion == '3':
            menu_product()
        elif opcion == '4':
            menu_sale()
        elif opcion == '5':
            print("Saliendo...")
            break
        else:
            print("Opción no válida.")

menu_principal()

