from calJSON import JsonFile
from company import Company
from customer import Client,RegularClient,VipClient
from product import Product
from sales import Sale
def menu_company():
    json_archivo = JsonFile("company.json")
    while True:
        print("*******************************************")
        print("Menú Empresa")
        print("1.Crear empresa")
        print("2.Leer empresas")
        print("3.Encontrar empresa")
        print("4.Borrar empresa")
        print("5.Salir")
        print("*******************************************")
        opcion = input("Ingrese su opción:")
        
        if opcion == '1':
            name = input("Ingrese el nombre de la empresa:")
            ruc = input("Ingrese el ruc de la empresa:")
            company = Company(name,ruc)
            data = json_archivo.read()
            data.append({'id':company.next,'business_name':company.business_name,'ruc':company.ruc})
            json_archivo.save(data)
            print("*******************************************")
            print(f"La empresa {name} ha sido creada correctamente.")
            print("*******************************************")
        elif opcion == '2':
            data = json_archivo.read()
            for company in data:
                print(f"Id:{company['id']} Empresa:{company['business_name']} Ruc:{company['ruc']}")
        
        elif opcion == '3':
            print("*******************************************")
            name = input("Ingrese nombre de la empresa: ")
            data = json_archivo.find("business_name",name)
            if data:
                for company in data:
                    print(f"Id:{company['id']} Empresa:{company['business_name']} Ruc:{company['ruc']}")
                print("*******************************************")
            else:
                print(f"Empresa {name} no registrada")
        
        elif opcion == '4':
            name = input("Nombre de la Empresa a borrar: ")
            if json_archivo.delete('business_name', name):
                print(f"Empresa '{name}' borrada exitosamente.")
            else:
                print(f"Empresa con nombre '{name}' no encontrada.")
        
        elif opcion == '5':
            break
        else:
            print("Opción no válida.")

def menu_customer():
    json_archivo = JsonFile("customer.json")
    while True:
        print("*******************************************")
        print("Menú Cliente")
        print("1.Crear cliente")
        print("2.Leer clientes")
        print("3.Encontrar cliente")
        print("4.Borrar cliente")
        print("5.Salir")
        print("*******************************************")
        opcion = input("Ingrese su opción:")

        if opcion == '1':
            tipo_cliente = input("Tipo de cliente [Regular/VIP]: ").strip().lower()
            first_name = input("Nombre: ")
            last_name = input("Apellido: ")
            dni = input("DNI: ")
            
            if tipo_cliente == 'regular':
                card = input("¿Tiene tarjeta? (s/n): ").strip().lower() == 's'
                client = RegularClient(first_name, last_name, dni, card)
                tipo = 'Regular'
            elif tipo_cliente == 'vip':
                client = VipClient(first_name, last_name, dni)
                tipo = 'Vip'
            else:
                print("Tipo de cliente no válido.")
                continue
            
            # Crear el diccionario con la información del cliente
            cliente_data = {
                'first_name': client.first_name,
                'last_name': client.last_name,
                'dni': client.dni,
                'type': tipo,
                'discount': getattr(client, 'discount', None),
                'limit': getattr(client, 'limit', None)
            }
            
            data = json_archivo.read()
            data.append(cliente_data)
            json_archivo.save(data)
            print(f"Cliente '{client.fullName()}' creado exitosamente.")

        elif opcion == '2':
            data = json_archivo.read()
            for client in data:
                if client.get('type') == 'Regular':
                    print(f"Regular - DNI: {client['dni']} Nombre: {client['first_name']} {client['last_name']} Descuento: {client['discount']*100}%")
                elif client.get('type') == 'Vip':
                    print(f"VIP - DNI: {client['dni']} Nombre: {client['first_name']} {client['last_name']} Cupo: {client['limit']}")
                else:
                    print(f"DNI: {client['dni']} Nombre: {client['first_name']} {client['last_name']}")
        
        elif opcion == '3':
            dni = input("DNI del Cliente a buscar: ")
            resultados = json_archivo.find('dni', dni)
            if resultados:
                for client in resultados:
                    if client.get('type') == 'Regular':
                        print(f"Regular - DNI: {client['dni']} Nombre: {client['first_name']} {client['last_name']} Descuento: {client['discount']*100}%")
                    elif client.get('type') == 'Vip':
                        print(f"VIP - DNI: {client['dni']} Nombre: {client['first_name']} {client['last_name']} Cupo: {client['limit']}")
            else:
                print(f"Cliente con DNI '{dni}' no encontrado.")

        elif opcion == '4':
            dni = input("DNI del Cliente a borrar: ")
            if json_archivo.delete('dni', dni):
                print(f"Cliente con DNI '{dni}' borrado exitosamente.")
            else:
                print(f"Cliente con DNI '{dni}' no encontrado.")

        elif opcion == '5':
            break
        else:
            print("Opción no válida.")

def menu_product():
    json_archivo = JsonFile("product.json")
    while True:
        print("*******************************************")
        print("Menú Producto")
        print("1.Crear Producto")
        print("2.Leer Productos")
        print("3.Encontrar Producto")
        print("4.Borrar Producto")
        print("5.Salir")
        print("*******************************************")
        opcion = input("Ingrese su opción:")
        
        if opcion == '1':
            descrip = input("Descripción del Producto: ")
            preci = float(input("Precio del Producto: "))
            stock = int(input("Stock del Producto: "))

            product = Product(descrip, preci, stock)

            data = json_archivo.read()
            data.append({
                'id': product.__dict__.get('_Product__id'),
                'descrip': product.descrip,
                'preci': product.preci,
                'stock': product.stock
            })
            json_archivo.save(data)
            print(f"Producto '{product.descrip}' creado exitosamente.")
        
        elif opcion == '2':
            data = json_archivo.read()
            for product in data:
                print(f"ID: {product['id']} Descripción: {product['descrip']} Precio: {product['preci']} Stock: {product['stock']}")

        elif opcion == '3':
            product_id = int(input("ID del Producto a buscar: "))
            resultados = json_archivo.find('id', product_id)
            if resultados:
                for product in resultados:
                    print(f"ID: {product['id']} Descripción: {product['descrip']} Precio: {product['preci']} Stock: {product['stock']}")
            else:
                print(f"Producto con ID '{product_id}' no encontrado.")

        elif opcion == '4':
            product_id = int(input("ID del Producto a borrar: "))
            if json_archivo.delete('id', product_id):
                print(f"Producto con ID '{product_id}' borrado exitosamente.")
            else:
                print(f"Producto con ID '{product_id}' no encontrado.")

        elif opcion == '5':
            break
        else:
            print("Opción no válida.")


def menu_sale():
    json_sales = JsonFile("sales.json")
    json_customers = JsonFile("customer.json")
    json_companies = JsonFile("company.json")
    json_products = JsonFile("product.json")

    while True:
        print("*******************************************")
        print("Menú Venta")
        print("1.Crear Venta")
        print("2.Leer Ventas")
        print("3.Encontrar Venta")
        print("4.Borrar Venta")
        print("5.Salir")
        print("*******************************************")
        opcion = input("Ingrese su opción:")

        if opcion == '1':
            # Verificar Cliente
            customer_dni = input("Ingrese DNI del cliente: ")
            customer_data = json_customers.find('dni', customer_dni)
            if not customer_data:
                print(f"Cliente con DNI '{customer_dni}' no encontrado.")
                continue
            
            customer = customer_data[0]
            customer_type = customer.get('type')
            if customer_type == 'Regular':
                client = RegularClient(customer['first_name'], customer['last_name'], customer['dni'], customer.get('card', False))
                discount = customer.get('discount', 0)
            elif customer_type == 'Vip':
                client = VipClient(customer['first_name'], customer['last_name'], customer['dni'])
                discount = 0
            else:
                print("Tipo de cliente no válido.")
                continue
            
            # Seleccionar Empresa
            print("Seleccione la Empresa que hace la factura:")
            companies = json_companies.read()
            for company in companies:
                print(f"ID: {company['id']} Nombre: {company['business_name']} RUC: {company['ruc']}")
            
            company_id = input("Ingrese el ID de la Empresa: ")
            company_data = json_companies.find('id', int(company_id))
            if not company_data:
                print(f"Empresa con ID '{company_id}' no encontrada.")
                continue
            
            company = Company(company_data[0]['business_name'], company_data[0]['ruc'])
            
            # Crear la Venta
            sale = Sale(client,company)
            
            # Agregar detalles de la venta
            while True:
                product_id = int(input("Ingrese el ID del producto: "))
                quantity = int(input("Ingrese la cantidad: "))
                products = json_products.read()
                product_data = next((p for p in products if p['id'] == product_id), None)
                if not product_data:
                    print("Producto no encontrado.")
                    continue

                product = Product(product_data['descrip'], product_data['preci'], product_data['stock'])
                sale.add_detail(product, quantity)

                more_products = input("¿Desea agregar otro producto? (s/n): ").strip().lower()
                if more_products != 's':
                    break

            if discount > 0:
                sale.cal_discount(discount)
            
            sale.print_invoice(company)

            print("Venta realizada con éxito.")
            
            # Guardar la venta
            data = json_sales.read()
            data.append({
                'id': sale.invoice,
                'customer_dni': sale.client.dni,
                'company': {
                    'business_name': company.business_name,
                    'ruc': company.ruc
                },
                'total': sale.total,
                'details': [{'quantity': detail.quantity, 'price': detail.preci} for detail in sale.sale_detail]
            })
            json_sales.save(data)
        
        elif opcion == '2':
            # Leer y mostrar todas las ventas
            sales_data = json_sales.read()
            if not sales_data:
                print("No hay ventas registradas.")
            else:
                for sale in sales_data:
                    print(f"ID: {sale['id']}, Cliente DNI: {sale['customer_dni']}, Total: {sale['total']}")
                    print("Detalles:")
                    for detail in sale['details']:
                        print(f"Cantidad: {detail['quantity']}, Precio: {detail['price']}")
                    print()
        
        elif opcion == '3':
            # Encontrar venta por ID
            sale_id = input("Ingrese el ID de la venta: ")
            sales_data = json_sales.read()
            sale = next((s for s in sales_data if s['id'] == sale_id), None)
            if not sale:
                print(f"No se encontró venta con ID '{sale_id}'.")
            else:
                print(f"ID: {sale['id']}, Cliente DNI: {sale['customer_dni']}, Total: {sale['total']}")
                print("Detalles:")
                for detail in sale['details']:
                    print(f"Cantidad: {detail['quantity']}, Precio: {detail['price']}")
                print()
        
        elif opcion == '4':
            # Borrar venta por ID
            sale_id = input("Ingrese el ID de la venta a borrar: ")
            sales_data = json_sales.read()
            updated_sales = [s for s in sales_data if s['id'] != sale_id]
            if len(updated_sales) == len(sales_data):
                print(f"No se encontró venta con ID '{sale_id}' para borrar.")
            else:
                json_sales.save(updated_sales)
                print(f"Venta con ID '{sale_id}' borrada con éxito.")

        elif opcion == '5':
            print("Saliendo del menú de ventas.")
            break

        else:
            print("Opción no válida. Inténtelo de nuevo.")

