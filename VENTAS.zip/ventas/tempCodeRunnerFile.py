
        # Método especial para representar la